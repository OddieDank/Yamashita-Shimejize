#version 120

#define THE_NETHER

#include "/program/gbuffers_clouds.vsh"
